using System;
using System.Collections.Generic;
using MediaInteractiveaAPI.Services.Controllers;
using MediaInteractiveaAPI.Services.Services;
using MediaInteractiveaAPI.Services.ViewModels;
using AutoMapper;
using Xunit;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;

namespace MediaTest
{
    public class EmployeeControllerTest
    {
        private readonly IEmployeeServices _employeeServices;
        private readonly IMapper _mapper;
        private int _status;
        public EmployeeControllerTest(IEmployeeServices employeeServices, IMapper mapper)
        {
            _employeeServices = employeeServices;
            _mapper = mapper;
        }

        [Fact]
        public void Test1()
        {
            //Arrange
            var controller = new EmployeeController(_employeeServices,_mapper);

            //Act
            var result = controller.GetEmployees();

            //Assert
            Assert.NotNull(result);
            OkObjectResult resulttest = result as OkObjectResult;
            Assert.NotNull(resulttest);


        }
    }
}
